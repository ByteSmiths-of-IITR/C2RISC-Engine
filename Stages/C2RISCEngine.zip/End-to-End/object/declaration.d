object/declaration.o: src/declaration.cpp include/header.h \
  include/utility.h
include/header.h:
include/utility.h:
