object/type.o: src/type.cpp include/header.h include/utility.h
include/header.h:
include/utility.h:
