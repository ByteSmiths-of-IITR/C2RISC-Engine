object/statements.o: src/statements.cpp include/header.h \
  include/utility.h
include/header.h:
include/utility.h:
