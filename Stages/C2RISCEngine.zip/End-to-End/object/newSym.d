object/newSym.o: src/newSym.cpp include/header.h include/utility.h
include/header.h:
include/utility.h:
