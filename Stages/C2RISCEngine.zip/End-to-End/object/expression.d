object/expression.o: src/expression.cpp include/header.h \
  include/utility.h
include/header.h:
include/utility.h:
