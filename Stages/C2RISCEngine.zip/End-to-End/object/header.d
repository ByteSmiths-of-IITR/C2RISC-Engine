object/header.o: src/header.cpp include/header.h include/utility.h
include/header.h:
include/utility.h:
