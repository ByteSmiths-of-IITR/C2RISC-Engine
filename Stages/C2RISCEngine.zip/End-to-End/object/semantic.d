object/semantic.o: src/semantic.cpp include/header.h include/utility.h
include/header.h:
include/utility.h:
