object/sym.o: src/sym.cpp include/header.h include/utility.h
include/header.h:
include/utility.h:
